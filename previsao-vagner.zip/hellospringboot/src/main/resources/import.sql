insert into previsao (dia,maxima,minima,humidade,descricao) values ('19/09',32,22,13,'Umidade relativa do ar baixa');
insert into previsao (dia,maxima,minima,humidade,descricao) values ('20/09',15,10,10,'Temperatura baixa com qualidade do ar ruim');
insert into previsao (dia,maxima,minima,humidade,descricao) values ('21/09',25,22,15,'Umidade do ar continua baixa');
insert into previsao (dia,maxima,minima,humidade,descricao) values ('22/09',20,15,20.5,'Tempo mediano');
insert into previsao (dia,maxima,minima,humidade,descricao) values ('23/09',22,17,35,'Temperaturas começam a subir');
insert into previsao (dia,maxima,minima,humidade,descricao) values ('24/09',23,19,24,'Umidade do ar aumenta');
insert into previsao (dia,maxima,minima,humidade,descricao) values ('25/09',28,25,20,'Temperatura e umidade sobem');


insert into usuario (id, login, senha) values (1, 'admin', 'admin');